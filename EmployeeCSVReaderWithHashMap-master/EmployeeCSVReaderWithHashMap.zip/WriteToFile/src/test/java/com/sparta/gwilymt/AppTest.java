/* TESTS YET TO BE IMPLEMENTED WITH REST OF THE PROJECT
package com.sparta.gwilymt;

        import org.junit.jupiter.api.Assertions;
        import org.junit.jupiter.api.Test;


public class AppTest {

   */
/* @Test
    public void testThatReaderEntryContainsTenElements() {
        Assertions.assertTrue(CSVFileReader.readFileToString(););

    } *//*


 */
/* @Test
    public void testThatAllEmpIDsAreUnique() {
        Assertions
    }*//*


 */
/*@Test
    public void testThatAllEmpIDsAreNumeric() {
        Assertions.assertTrue(Number.isInteger(E.getEmpID()));
    } *//*

    @Test
    void testThatTitleIsValid() {
        Assertions.assertTrue(Employee.getTitle().equals("Mr.") ||
                Employee.getTitle().equals("Mrs.") ||
                Employee.getTitle().equals("Ms.") ||
                Employee.getTitle().equals("Dr.") ||
                Employee.getTitle().equals("Drs.") ||
                Employee.getTitle().equals("Hon.") ||
                Employee.getTitle().equals("Prof."));
    }

    @Test
    public void testThatFirstNameIsAllAlpha() {
        Assertions.assertTrue(Employee.getFirstName().matches("[a-zA-Z]+"));
    }

    @Test
    public void testThatMiddleInitialIsOneCharacter() {
        Assertions.assertTrue(Employee.getMiddleInitialLength()==(1));
    }

    @Test
    public void testThatMiddleInitialIsAlpha() {
        Assertions.assertTrue(Employee.getMiddleInitial().matches("[a-zA-Z]+"));
    }

    @Test
    public void testThatLastNameIsAllAlpha() {
        Assertions.assertTrue(Employee.getLastName().matches("[a-zA-Z]+"));
    }

    @Test
    public void testThatGenderIsOneOfTwoValues() {
        Assertions.assertTrue(Employee.getGender().equals("M") ||
                Employee.getGender().equals("F"));
    }

    @Test
    public void testEmailForAt() {
        Assertions.assertTrue(Employee.getEmail().contains("@"));
    }

    @Test
    public void testEmailForDotCount() {
        Assertions.assertTrue(Employee.getEmailDotCount() == 2 || Employee.getEmailDotCount() == 3);
    }

    */
/*@Test
    public void DateOfBirthInitialFormat() {
        //test
    }

    @Test
    public void JoinDateInitialFormat() {
        //test
    } *//*


}
*/
